import { LightningElement, wire } from 'lwc';

export default class LiveSearch extends LightningElement {
    searchTerm = '';
    handleSearchChange(event) {
        this.searchTerm = event.target.value;
        if(this.searchTerm.length>=2) {
            const customEvent = new CustomEvent('searchTerm', {
                detail: this.searchTerm
            });
            console.log("customEvent==>",customEvent);
            this.dispatchEvent(customEvent); 
        }

    }
}
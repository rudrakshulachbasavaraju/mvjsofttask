import { LightningElement } from 'lwc';
import searchRecords from '@salesforce/apex/SearchRecordsController.searchRecords';

export default class ShowDocuments extends LightningElement {
searchTerm = '';
docs = [];
dataWithButtons = [];
// Define columns for the datatable
columns = [
    {label: 'Document Name', fieldName: 'Name', type: 'text'},
    {label: 'Document Version', fieldName: 'Document_Version__c', type: 'text'},
    {label: 'Document Category', fieldName: 'Document_Category__c', type: 'text'},
    {
        type: 'action',
        typeAttributes: { rowActions: this.getRowActions },
    }
];
connectedCallback() {
    this.addEventListener('searchTerm', this.handleCustomEvent);
}

handleCustomEvent(event) {
    this.searchTerm = event.detail;
    console.log('searchTerm==>',this.searchTerm);
    this.performSearch();
}

performSearch() {
    searchRecords()
        .then(result => {
            this.docs = result;
            this.dataWithButtons = this.docs.map(item => ({
                ...item,
                actions: {
                    label: 'Remove',
                    name: 'remove',
                    iconName: 'utility:delete',
                },
            }));
            
        })
        .catch(error => {
            console.error('Error fetching accounts:', error);
        });
}

getRowActions(row, doneCallback) {
    const actions = [];
    actions.push({ label: 'Remove', name: 'remove' });
    doneCallback(actions);
}

handleRowAction(event) {
    const actionName = event.detail.action.name;
    if (actionName === 'remove') {
        const row = event.detail.row;
        this.docs.splice(row);
    }
}
}